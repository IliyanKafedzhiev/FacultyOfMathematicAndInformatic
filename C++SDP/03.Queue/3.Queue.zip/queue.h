/*
 * queue.h
 *
 *  Created on: 07.11.2012
 *      Author: trifon
 */

#ifndef QUEUE_H_
#define QUEUE_H_

#include <iostream>
using namespace std;

template <typename T>
class Queue
{
public:
	virtual bool empty() const = 0;
	virtual bool push(T const&) = 0;
	virtual bool pop(T&) = 0;
	virtual bool head(T&) = 0;
};


#endif /* QUEUE_H_ */
