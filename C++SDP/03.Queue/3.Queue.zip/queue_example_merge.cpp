#include <iostream>
using namespace std;

#include "squeue.cpp"
#include "lqueue.cpp"

template <typename T>
void merge(Queue<T>& first, Queue<T>& second, Queue<T>& result)
{

	T temp;

	while (! (first.empty() || second.empty()))
	{
		T headFirst;
		first.head(headFirst);
		T headSecond;
		second.head(headSecond);

		if (headFirst <= headSecond)
		{
			result.push(headFirst);
			first.pop(temp);
		}
		else
		{
			result.push(headSecond);
			second.pop(temp);
		}
	}

	// ще се изпълни най-много един от следващите цикли

	while (! first.empty())
	{
		first.pop(temp);
		result.push(temp);
	}

	while (! second.empty())
	{
		second.pop(temp);
		result.push(temp);
	}
}

/*int main()
{

	SQueue<int> q1;
	q1.push(1);
	q1.push(3);
	q1.push(5);

	LQueue<int> q2;
	q2.push(2);
	q2.push(4);
	q2.push(6);
	q2.push(8);

	LQueue<int> result;

	merge(q1, q2, result);

	result.print();

	return 0;
}*/

