/*
 * queue_examples.cpp
 *
 *  Created on: 14.11.2012
 *      Author: trifon
 */

#include <iostream>
using namespace std;

#include "lqueue.cpp"

void numbers235()
{
	int n;
	cout << "n = ";
	cin >> n;
	LQueue<> q2, q3, q5;
	q2.push(2);
	q3.push(3);
	q5.push(5);

	for(int i=0; i<n; i++)
	{
		int x2, x3, x5, x;
		q2.head(x2);
		q3.head(x3);
		q5.head(x5);
		x = x2;
		if (x3 < x)
			x = x3;
		if (x5 < x)
			x = x5;
		// x = min(x2,x3,x5)
		if (x == x2)
			q2.pop(x2);
		if (x == x3)
			q3.pop(x3);
		if (x == x5)
			q5.pop(x5);
		cout << x << endl;
		q2.push(x*2);
		q3.push(x*3);
		q5.push(x*5);
	}
	//cout << "q2:";
	//q2.print();
	//cout << endl;
}

int minQueue(LQueue<>& q)
{
	int min, x;
	q.pop(min);
	// слагаме сентинела
	q.push(0);
	while (q.pop(x) && x > 0)
	{
		if (min < x)
			q.push(x);
		else
		{
			q.push(min);
			min = x;
		}
	}
	return min;
}

void readQueue(LQueue<>& q)
{
	int n;
	cin >> n;
	while (n > 0)
	{
		q.push(n);
		cin >> n;
	}
}

void findMinQueue()
{
	LQueue<> q;
	readQueue(q);
	q.print();cout << endl;
	cout << "minQueue = " << minQueue(q) << endl;
	q.print();cout << endl;
}

void sortQueue()
{
	LQueue<> q;
	readQueue(q);
	LQueue<> sortedq;
	while (!q.empty())
		sortedq.push(minQueue(q));
	sortedq.print();
}

/*int main()
{
	numbers235();
	// findMinQueue();
	// sortQueue();
	return 0;
}
*/

